package com.example.athena.udf;

import com.amazonaws.athena.proxy.UserDefinedFunctionHandler;

public class SimpleStringConcatUDF extends UserDefinedFunctionHandler {

    private static final String SOURCE_TYPE = "MyAthenaUDF";

    public SimpleStringConcatUDF() {
        super(SOURCE_TYPE);
    }

    /**
     * Concatena duas strings.
     * Este método deve ser em letras minúsculas para ser chamado pelo Athena.
     *
     * @param str1 A primeira string.
     * @param str2 A segunda string.
     * @return A concatenação das duas strings.
     */
    public String concat_strings(String str1, String str2) {
        if (str1 == null && str2 == null) {
            return null;
        }
        if (str1 == null) {
            return str2;
        }
        if (str2 == null) {
            return str1;
        }
        return str1 + str2;
    }
}

