package com.example.athena.udf;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class SimpleStringConcatUDFTest {

    private SimpleStringConcatUDF udf;

    @Before
    public void setUp() {
        udf = new SimpleStringConcatUDF();
    }

    @Test
    public void testConcatStrings_both_valid() {
        assertEquals("HelloWorld", udf.concat_strings("Hello", "World"));
    }

    @Test
    public void testConcatStrings_first_null() {
        assertEquals("World", udf.concat_strings(null, "World"));
    }

    @Test
    public void testConcatStrings_second_null() {
        assertEquals("Hello", udf.concat_strings("Hello", null));
    }

    @Test
    public void testConcatStrings_both_null() {
        assertNull(udf.concat_strings(null, null));
    }

    @Test
    public void testConcatStrings_first_empty() {
        assertEquals("World", udf.concat_strings("", "World"));
    }

    @Test
    public void testConcatStrings_second_empty() {
        assertEquals("Hello", udf.concat_strings("Hello", ""));
    }

    @Test
    public void testConcatStrings_both_empty() {
        assertEquals("", udf.concat_strings("", ""));
    }

    @Test
    public void testConcatStrings_with_spaces() {
        assertEquals("Hello World", udf.concat_strings("Hello ", "World"));
    }
}

